<footer class="bg-dark text-white text-center py-3 mt-5">
    <p>&copy; 2025 Fitness Center</p>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>